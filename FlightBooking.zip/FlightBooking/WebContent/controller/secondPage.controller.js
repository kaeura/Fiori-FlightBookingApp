sap.ui.define([
	
	"fiori/demo/util/BaseController",
	"sap/m/MessageToast",
	"sap/ui/unified/DateRange"
		], function(BaseController, MessageToast, DateRange){
	
	"use strict";
	
	return BaseController.extend("fiori.demo.controller.secondPage", {
		
   
		
	});
	
});