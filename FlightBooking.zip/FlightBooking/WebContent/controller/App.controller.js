sap.ui.define([
	
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast",
	"sap/ui/unified/DateRange"
		], function(Controller, MessageToast, DateRange){
	
	"use strict";
	
	return Controller.extend("fiori.demo.controller.App", {
		
	});
	
});